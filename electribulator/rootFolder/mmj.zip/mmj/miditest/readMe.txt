Quick demo for the mmj CoreMidi wrapper.

The miditest target contains a "Copy Files" build step, that copies mmj.jar and libmmj.jnilib into the application bundle.
To test the app with libraries in the standard extensions folder, doubleclick the build step and check the "copy only when installing" checkbox,
clean all targets, make sure that mmj jar and jnilib are in /Library/Java/Extensions, rebuild and run.

