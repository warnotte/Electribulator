Thanx for your interest in mmj!

To make mmj available to all Java applications simply drop both mmj.jar and libmmj.jnilib into /Library/Java/Extensions.

To use the library exclusively add mmj.jar & libmmj.jnilib to your XCode project and define a
"Copy files" build phase at some appropriate place, that copies both files to the /Contents/Resources/Java 
subdirectory of your application bundle.

Please let us know about bugs and issues you might find in mmj. 

Send feedback to: np at humatic dot de

___________________________________________________________________________________________________________

Use terms:
mmj is released under a Creative Commons Attribution-Non-Commercial-No Derivative Works 3.0 Germany License. You may 
freely use it with non commercial applications under the terms layed out there. Please note that you
may only use and share it "alike", that is: in compiled binary form. We do not provide source code
with the library nor do we grant you any rights to decompile the library and use or extend the source. 
To view the license, point your browser to: 
http://creativecommons.org/licenses/by-nc-nd/3.0/de/deed.en_GB

Selling, leasing, renting and other use of the library for commercial purposes is prohibited unless you enter 
a commercial license agreement with us.

mmj - copyright 2007-9,  Nils Peters, humatic GmbH, Leuschnerdamm 19, 10999 Berlin, Germany

___________________________________________________________________________________________________________

change log:

0.90
64bit java compatible

0.88
Added options to enable ActiveSensing, which mmj by default filters out on the native side

0.87
More bugfixes on the SPI implementation. Should now reflect device removal & adding.

0.86
Changed the way the javasound SPI enumerates devices to bring it in line with the Windows javax.sound.midi api
Devices that do not have both in and outputs are no longer filtered out by the javasound SPI

0.85
Removed all use of SysExSendRequest from SysEx output related code. This seems to work better for people that actually have a use for extensive SysEx sending (which I do not have. So, if you experience problems with this, please let me know)
Separated the test app from the library jar. Now supplied with "full source" and XCode project.

0.84
Fixes problem with input port java objects left alive after device removal

0.83
Fixes a static field bug, that obscured port names

0.82
Fixes a problem with lengthy MIDIPacketLists

0.81
Fixes problem with javax.sound.midi.spi and offline interfaces

0.8.
Catches up with a great deal of unfinished business in terms of SysEx sending and receiving and fixes some
more or less stupid bugs.
mmj.jar now includes a little double-click startable test-app (open Console  to see incoming midi).  

0.7
This introduces a change in the main internal callback method as the previous versions occasionally crashed after
hours. Though it seems to be stable, the fix is basically wrong JNI. In case you experience any problems (most
likely related to threads and MIDI Input), please let us know. The previous version is still available at
http://www.humatic.de/htools/mmj/mmj06.zip in case you want to crosscheck.

0.6
Implemented proper handling of timestamped events sent to an output. While timestamps were ignored before and
messages fired immediately, mmj now schedules them for sending correctly (CoreMIDI allows for very accurate
scheduling and pretty long periods into the future). This is valid for non-virtual ports only.

0.5
Initial release.